SGM-Census
==========

---
## Instructions

**Usage**

    ./sgm <right image> <left image>  <gt depth map> <output image file> <disparity range>

**Examples**

    ./sgm Examples/Rocks1/right.png Examples/Rocks1/left.png Examples/Rocks1/rightGT.png output_disparity.png 85

---


